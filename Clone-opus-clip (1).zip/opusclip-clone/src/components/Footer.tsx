import type React from 'react';
import Logo from './Logo';
import { FaTwitter, FaLinkedin, FaInstagram, FaYoutube } from 'react-icons/fa';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0a0a0b] pt-16 pb-8 px-4 md:px-8 lg:px-16">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div>
            <Logo className="mb-6" />
            <p className="text-gray-400 mb-4">
              Turn long videos into high-quality viral clips, and publish them to all social platforms in one click.
            </p>
            <div className="flex space-x-4">
              <SocialIcon icon={<FaTwitter />} href="https://twitter.com/opusclip" />
              <SocialIcon icon={<FaLinkedin />} href="https://linkedin.com/company/opusclip" />
              <SocialIcon icon={<FaInstagram />} href="https://instagram.com/opusclip" />
              <SocialIcon icon={<FaYoutube />} href="https://youtube.com/opusclip" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Product</h3>
            <ul className="space-y-2">
              <FooterLink href="#features">Features</FooterLink>
              <FooterLink href="#pricing">Pricing</FooterLink>
              <FooterLink href="#testimonials">Testimonials</FooterLink>
              <FooterLink href="#faq">FAQ</FooterLink>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Company</h3>
            <ul className="space-y-2">
              <FooterLink href="#about">About Us</FooterLink>
              <FooterLink href="#careers">Careers</FooterLink>
              <FooterLink href="#blog">Blog</FooterLink>
              <FooterLink href="#contact">Contact</FooterLink>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Resources</h3>
            <ul className="space-y-2">
              <FooterLink href="#tutorials">Tutorials</FooterLink>
              <FooterLink href="#docs">Documentation</FooterLink>
              <FooterLink href="#community">Community</FooterLink>
              <FooterLink href="#api">API</FooterLink>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 mt-8 text-gray-400 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} OpusClip. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <FooterLink href="#terms">Terms of Service</FooterLink>
            <FooterLink href="#privacy">Privacy Policy</FooterLink>
            <FooterLink href="#cookies">Cookie Policy</FooterLink>
          </div>
        </div>
      </div>
    </footer>
  );
};

interface FooterLinkProps {
  href: string;
  children: React.ReactNode;
}

const FooterLink: React.FC<FooterLinkProps> = ({ href, children }) => {
  return (
    <li>
      <a href={href} className="text-gray-400 hover:text-white transition-colors">
        {children}
      </a>
    </li>
  );
};

interface SocialIconProps {
  icon: React.ReactNode;
  href: string;
}

const SocialIcon: React.FC<SocialIconProps> = ({ icon, href }) => {
  return (
    <a
      href={href}
      className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-[#5a2cf7] hover:text-white transition-colors"
    >
      {icon}
    </a>
  );
};

export default Footer;
