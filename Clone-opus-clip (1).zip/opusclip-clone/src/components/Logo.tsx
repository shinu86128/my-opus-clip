import type React from 'react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = '' }) => {
  return (
    <div className={`flex items-center ${className}`}>
      <div className="mr-2">
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M16 2C8.268 2 2 8.268 2 16C2 23.732 8.268 30 16 30C23.732 30 30 23.732 30 16C30 8.268 23.732 2 16 2ZM16 6C18.946 6 21.518 7.348 23.192 9.5H8.808C10.482 7.348 13.054 6 16 6ZM7 14.5C7 11.462 9.462 9 12.5 9C15.538 9 18 11.462 18 14.5C18 17.538 15.538 20 12.5 20C9.462 20 7 17.538 7 14.5ZM16 26C13.054 26 10.482 24.652 8.808 22.5H23.192C21.518 24.652 18.946 26 16 26ZM21 20.5C21 17.462 23.462 15 26.5 15C26.67 15 26.838 15.008 27 15.025V16.975C26.838 16.992 26.67 17 26.5 17C24.568 17 23 18.568 23 20.5C23 22.432 24.568 24 26.5 24C26.67 24 26.838 24.008 27 24.025V25.975C26.838 25.992 26.67 26 26.5 26C23.462 26 21 23.538 21 20.5Z"
            fill="white"
          />
        </svg>
      </div>
      <span className="text-white font-semibold text-xl">OpusClip</span>
    </div>
  );
};

export default Logo;
