import type React from 'react';
import Logo from './Logo';
import { motion } from 'framer-motion';

const Navbar: React.FC = () => {
  return (
    <nav className="py-4 px-4 md:px-8 lg:px-16">
      <div className="container mx-auto flex justify-between items-center">
        <Logo />

        <div className="hidden md:flex space-x-8 items-center">
          <NavLink href="#business">Business</NavLink>
          <NavLink href="#customer-stories">Customer stories</NavLink>
          <NavLink href="#pricing">Pricing</NavLink>
          <NavLink href="#learning-center">Learning center</NavLink>
          <button className="text-white font-medium">Sign in</button>
          <motion.button
            className="btn-primary"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Sign up - it's Free
          </motion.button>
        </div>

        <button className="md:hidden">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 12H21" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M3 6H21" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M3 18H21" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
    </nav>
  );
};

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ href, children }) => {
  return (
    <a href={href} className="text-gray-300 hover:text-white transition-colors underline-animation">
      {children}
    </a>
  );
};

export default Navbar;
