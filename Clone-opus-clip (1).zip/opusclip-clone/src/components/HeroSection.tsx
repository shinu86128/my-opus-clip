import type React from 'react';
import { motion } from 'framer-motion';

const HeroSection: React.FC = () => {
  return (
    <section className="pt-10 pb-16 px-4 md:px-8 lg:px-16">
      <div className="container mx-auto text-center">
        <div className="inline-block bg-[#132310] px-3 py-1 rounded-full text-[#4de877] text-sm font-medium mb-6">
          #1 AI VIDEO CLIPPING TOOL
        </div>

        <motion.h1
          className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          1 long video, 10 viral clips. <br />
          <span className="relative">
            Create 10x faster.
            <svg className="absolute w-full -bottom-2 left-0" viewBox="0 0 400 20" xmlns="http://www.w3.org/2000/svg">
              <path d="M0,10 Q100,0 200,10 Q300,20 400,10" stroke="#5a2cf7" strokeWidth="6" fill="none" />
            </svg>
          </span>
        </motion.h1>

        <motion.p
          className="text-lg md:text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          OpusClip turns long videos into shorts, and publishes them to all social platforms <span className="font-medium">in one click</span>. Powered by
          <svg className="inline-block ml-2 mr-1" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="11" stroke="white" strokeWidth="2"/>
            <path d="M7 12L10 15L17 8" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          OpenAI
        </motion.p>

        <motion.div
          className="flex flex-col md:flex-row justify-center items-center gap-4 mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="flex-1 max-w-md bg-[#151515] rounded-lg border border-gray-800 px-3 py-3 flex items-center">
            <svg className="w-5 h-5 text-gray-400 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
            <input
              type="text"
              placeholder="Drop a video link"
              className="flex-1 bg-transparent outline-none text-white"
            />
          </div>
          <span className="text-gray-500">or</span>
          <motion.button
            className="btn-outline"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Upload file
          </motion.button>
          <motion.button
            className="btn-primary"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get free clips
          </motion.button>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1504450758481-7338eba7524a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1769&q=80"
              alt="Podcast recording"
              className="rounded-lg shadow-lg w-full object-cover aspect-[4/3]"
            />
            <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-sm">
              Podcast scene
            </div>
          </div>
          <div className="relative mt-12 md:mt-0">
            <div className="absolute -right-2 -top-2 z-10 flex flex-col gap-1">
              <div className="bg-black/80 backdrop-blur-sm text-green-400 px-2 py-1 rounded text-xs">
                ✓ Viral Templates
              </div>
              <div className="bg-black/80 backdrop-blur-sm text-green-400 px-2 py-1 rounded text-xs">
                ✓ AI Curation
              </div>
              <div className="bg-black/80 backdrop-blur-sm text-green-400 px-2 py-1 rounded text-xs">
                ✓ Auto Reframe
              </div>
              <div className="bg-black/80 backdrop-blur-sm text-green-400 px-2 py-1 rounded text-xs">
                ✓ Auto Caption
              </div>
            </div>
            <img
              src="https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1774&q=80"
              alt="Podcast host"
              className="rounded-lg shadow-lg w-full object-cover aspect-[3/4]"
            />
            <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 bg-black/70 text-green-400 font-bold uppercase px-3 py-1 rounded text-sm backdrop-blur-sm">
              ACQUISITION
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
